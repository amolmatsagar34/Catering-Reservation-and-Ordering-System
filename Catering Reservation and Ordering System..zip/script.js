// Firebase configuration (replace with your Firebase project config)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore(); // Firestore database instance
const auth = firebase.auth(); // Firebase Authentication instance

// DOM Elements
const productList = document.getElementById("product-list");
const cartItems = document.getElementById("cart-items");
const placeOrderBtn = document.getElementById("place-order-btn");
const orderList = document.getElementById("order-list");
const profileForm = document.getElementById("profile-form");
const authForm = document.getElementById("auth-form");
const registerBtn = document.getElementById("register-btn");

// Fetch and display products from Firestore
function fetchProducts() {
    db.collection("products").get().then((querySnapshot) => {
        productList.innerHTML = ""; // Clear previous products
        querySnapshot.forEach((doc) => {
            const product = doc.data();
            const productElement = document.createElement("div");
            productElement.className = "product";
            productElement.innerHTML = `
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>Price: $${product.price}</p>
                <button onclick="addToCart('${doc.id}')">Add to Cart</button>
            `;
            productList.appendChild(productElement);
        });
    }).catch((error) => {
        console.error("Error fetching products: ", error);
    });
}

// Add product to cart
function addToCart(productId) {
    db.collection("cart").doc(productId).set({
        quantity: 1 // Default quantity
    }).then(() => {
        alert("Product added to cart!");
    }).catch((error) => {
        console.error("Error adding to cart: ", error);
    });
}

// Place order
placeOrderBtn.addEventListener("click", () => {
    db.collection("cart").get().then((querySnapshot) => {
        const items = [];
        querySnapshot.forEach((doc) => {
            items.push(doc.data());
        });
        return db.collection("orders").add({
            items: items,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    }).then(() => {
        alert("Order placed successfully!");
        // Clear the cart after placing the order
        db.collection("cart").get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                db.collection("cart").doc(doc.id).delete();
            });
        });
    }).catch((error) => {
        console.error("Error placing order: ", error);
    });
});

// Fetch and display orders
function fetchOrders() {
    db.collection("orders").get().then((querySnapshot) => {
        orderList.innerHTML = ""; // Clear previous orders
        querySnapshot.forEach((doc) => {
            const order = doc.data();
            const orderElement = document.createElement("div");
            orderElement.className = "order";
            orderElement.innerHTML = `
                <h3>Order ID: ${doc.id}</h3>
                <p>Items: ${JSON.stringify(order.items)}</p>
                <p>Date: ${order.timestamp.toDate().toLocaleString()}</p>
            `;
            orderList.appendChild(orderElement);
        });
    }).catch((error) => {
        console.error("Error fetching orders: ", error);
    });
}

// Update user profile
profileForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    db.collection("users").doc("currentUser").set({
        name: name,
        email: email
    }).then(() => {
        alert("Profile updated successfully!");
    }).catch((error) => {
        console.error("Error updating profile: ", error);
    });
});

// Login functionality
authForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    auth.signInWithEmailAndPassword(username, password)
        .then(() => {
            alert("Login successful!");
        })
        .catch((error) => {
            alert("Login failed: " + error.message);
        });
});

// Register functionality
registerBtn.addEventListener("click", () => {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    auth.createUserWithEmailAndPassword(username, password)
        .then(() => {
            alert("Registration successful!");
        })
        .catch((error) => {
            alert("Registration failed: " + error.message);
        });
});

// Initial fetch of products and orders
fetchProducts();
fetchOrders();